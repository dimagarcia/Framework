/*
 * Propiedad intelectual de la Universidad del Valle
 * Name:        CoefLinearGaussMod
 * Description: Coef Linear Gaussian Model
 * Author:      Diego Garcia
 * Date:        13th Octuber 2015
 *
 * Modification Log:
 * ---------------------------
 * 2015-10-13   Diego Garcia    Creation.
 */
package BN;

/**
 *
 * @author dgarcia
 */
public class CoefLinearGaussMod {
    public List < CoefNode > coef;
    
}
