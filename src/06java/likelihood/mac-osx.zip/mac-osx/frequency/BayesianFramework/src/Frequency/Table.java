/*
 * Propiedad intelectual de la Universidad del Valle
 * Name:        Table
 * Description: Frequency table
 * Author:      Diego Garcia
 * Date:        26th March 2016
 *
 * Modification Log:
 * ---------------------------
 * 2016-03-26   Diego Garcia    Creation.
 * 2016-03-29   Diego Garcia    Add m attribute
 */
package Frequency;

/**
 *
 * @author dgarcia
 */
public class Table {
    int[][][][][] frequency;
    public int[][] m;
    
    public Table(){
    }
    public Table(int[][][][][] frequency){
        this.frequency = frequency;
    }
}
