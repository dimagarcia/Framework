package Main;

import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
// Librerias JDBC
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSetMetaData;




/**
 * BayesianFramework.java <BR>
 * author: Brian Paul (converted to Java by Ron Cemer and Sven Goethel) <P>
 *
 * This version is equal to Brian Paul's version 1.2 1999/10/21
 */
public class BayesianFramework implements GLEventListener {

    public static void main(String[] args) {
        Frame frame = new Frame("Frequency Table");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new BayesianFramework());
        frame.add(canvas);
        frame.setSize(640, 480);
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
//        frame.setVisible(true);
//        animator.start();
        
//        Frequency.Table t = new Frequency.Table();   
        Frequency.Table ft = new Frequency.Table(new int[][][][][]{
            {// P=L
                {// S=T
                    {// C=T
                        {  47,   27},// X=pos
                        {   6,    2}// X=neg
                    },{// C=F   
                        { 149,  369},// X=pos
                        { 638, 1477}// X=neg
                    }
                },{// S=F
                    {// C=T
                        {   9,    4},// X=pos
                        {   0,    1}// X=neg
                    },{// C=F
                        { 381,  842},// X=pos
                        {1526, 3506}// X=neg
                    }
                }
            },{// P=H
                {// S=T
                    {// C=T
                        {   8,    4},// X=pos
                        {   0,    0}// X=neg
                    },{// C=F
                        {  20,   38},// X=pos
                        {  70,  166}// X=neg
                    }
                },{// S=F
                    {// C=T
                        {  13,    5},// X=pos
                        {   1,    0}// X=neg
                    },{// C=F
                        {  36,  101},// X=pos
                        { 171,  383}// X=neg
                    }
                }
            }
        });
        // 2016-mar-29 Dgarcia  Other version of the frequency tables
        ft.m = new int[][]  {
            {//i=1
                0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {//i=2
                0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1},
            {//i=3
                0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1},                
            {//i=4
                0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1},                
            {//i=5
                0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1},                                
            {//f32requency
                47,27,6,2,149,369,638,1477,9,4,0,1,381,842,1526,3506,
                8,4,0,0,20,38,70,166,13,5,1,0,36,101,171,383 
            }
        };
        
        // 2016-mar-27 09:37 Dgarcia Testing Frecuency Table and Calculus of probabilities
//        Likelihood.BayesianModel bm = new Likelihood.BayesianModel();
//        Sampler.BayesianMapper  map = new Sampler.BayesianMapper(5);//bm.v.length);
//        // set parent nodes
//        map.pa[2].insertAtBack(0);
//        map.pa[2].insertAtBack(1);
//        map.pa[3].insertAtBack(2);
//        map.pa[4].insertAtBack(2);  
        
        // 2016-mar-28 07:15 Dgarcia Testing calculus of parents cardinaly
        Likelihood.BayesianModel bm = new Likelihood.BayesianModel(
                // Define Pijk vector
                new float[][][]{
                    {//i=1
                        {// j=1                            
                                0.9f // k=1
                        },
                        {// j=2
                                0.1f // k=1
                        }
                    },
                    {//i=2
                        {// j=1
                                0.3f // k=1
                        },
                        {// j=2
                                0.7f // k=1
                        }
                    },
                    {//i=3
                        {// j=1
                                0.05f, 0.02f, 0.03f, 0.001f // k=1,2,3,4
                        },
                        {// j=2
                                0.95f, 0.98f, 0.97f, 0.999f // k=1,2,3,4
                        }

                    },
                    {//i=4
                        {// j=1
                                0.9f, 0.2f // k=1,2
                        },
                        {// j=2
                                0.1f, 0.8f // k=1,2
                        }
                    },
                    {//i=5
                        {// j=1
                                0.65f, 0.3f // k=1,2
                        },
                        {// j=2
                                0.35f, 0.7f // k=1,2
                        }
                        
                    }
                },
                // Define Nijk vector
                new int[][][]{
                    {//i=1
                        {// j=1                            
                                1016 // k=1
                        },
                        {// j=2
                                8984 // k=1
                        }
                    },
                    {//i=2
                        {// j=1
                                3021 // k=1
                        },
                        {// j=2
                                6979 // k=1
                        }
                    },
                    {//i=3
                        {// j=1
                                12, 19, 82, 14 // k=1,2,3,4
                        },
                        {// j=2
                                294, 691, 2633, 6255 // k=1,2,3,4
                        }
                    },
                    {//i=4
                        {// j=1
                                117, 1936 // k=1,2
                        },
                        {// j=2
                                10, 7937 // k=1,2
                        }
                    },
                    {//i=5
                        {// j=1
                                84, 2991 // k=1,2
                        },
                        {// j=2
                                43, 6882 // k=1,2
                        }
                        
                    }                    
                },
                // Define Vi vector
                new int[]{1,2,3,4,5},
                // Define Ri vector
                new int[]{2,2,2,2,2},
                // Define Qi vector
                new int[]{1,1,4,2,2}
        );                
        // set parent nodes
        bm.pa[2].insertAtBack(0);
        bm.pa[2].insertAtBack(1);
        bm.pa[3].insertAtBack(2);
        bm.pa[4].insertAtBack(2);         
        
        Sampler.BayesianMapper  map = new Sampler.BayesianMapper();
        
        //bm.q = map.getQ(bm, ft);        
        // OK 2016-03-29 testing getQ
        int[] tmp = map.getQ(bm);
        for (int i=0; i<tmp.length; i++)
            System.out.println("Q["+i+"]="+tmp[i]);
        
        // Conexion a oracle
        int Nijk = 0;
        try{
            DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
            Connection conn = DriverManager.getConnection
                //("jdbc:oracle:thin:@192.168.1.52:1521:XE", "bio", "Abril2016");//"bayesian");
                ("jdbc:oracle:thin:@192.168.56.101:1521:XE", "bio", "Abril2016");//"bayesian");
            // driver@machineName:port:SID           ,  userid,  password
            Statement stmt = conn.createStatement();
            ResultSet rset = 
              stmt.executeQuery(
//                "select id as i, value as x, fnuDistrNormal(value, 0, 1) as u from dnorm"
//"SELECT (SELECT  sum(f.freqvalu) "+
//"FROM 	frequency f "+
//"WHERE	f.sampleid IN "+
//"(SELECT 	s1.sampleid "+
//" FROM 	SAMPLE s1, SAMPLE s2, SAMPLE s3 "+
//" WHERE   s1.VARINAME = 1 AND s1.VARIVALU = 1  AND "+
//"		s2.VARINAME = 2 AND s2.VARIVALU = 0  AND "+
//"		s3.VARINAME = 3 AND s3.VARIVALU = 0  AND "+
//"	s1.sampleid = s2.sampleid AND  "+
//"	s2.sampleid = s3.sampleid) "+
//") / ("+
//"SELECT  sum(f.freqvalu) "+
//"FROM 	frequency f "+
//"WHERE	f.sampleid IN "+
//"(SELECT 	s1.sampleid "+
//" FROM 	SAMPLE s1, SAMPLE s2 "+
//" WHERE  s1.VARINAME = 1 AND s1.VARIVALU = 1  AND "+
//"		s2.VARINAME = 2 AND s2.VARIVALU = 0  AND "+
//"		s1.sampleid = s2.sampleid)	"+
//")  FROM DUAL"    
                      "select * from FREQUENCY where rownum<5"
                      //"select distinct sampleid from sample where rownum<5 order by sampleid"
              );            
            while (rset.next()){
                //System.out.println (rset.getString(1));   // Print col 1
                System.out.println (rset.getString(1)+" "+rset.getString(2));   // Print col 1
//                float p = rset.getFloat(1);//getInt(1);
//                x1[i-1] = rset.getFloat(2);
//                u1[i-1] = rset.getFloat(3);                
//                System.out.printf ("=> %.4f \n",p); //(rset.getString(1));   // Print col 1
            }            
            // Para ejecutar INSERT, UPDATE, DELETE;
            // stmt.executeUpdate("INSERT .. ");
            stmt.close();        
        }
	catch (SQLException e){e.printStackTrace();}

        /*
        try{
            DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
            Connection conn = DriverManager.getConnection
                ("jdbc:oracle:thin:@192.168.56.101:1521:XE", "bio", "bayesian");
            // driver@machineName:port:SID           ,  userid,  password
            Statement stmt = conn.createStatement();
            ResultSet rset = 
              stmt.executeQuery("select id as i, value as x, fnuDistrNormal(value, 0, 1) as u from dnorm");            
            while (rset.next()){
                //System.out.println (rset.getString(1));   // Print col 1
                int i = rset.getInt(1);
                x1[i-1] = rset.getFloat(2);
                u1[i-1] = rset.getFloat(3);                
            }            
            // Para ejecutar INSERT, UPDATE, DELETE;
            // stmt.executeUpdate("INSERT .. ");
            stmt.close();        
        }
	catch (SQLException e){e.printStackTrace();}
        */
        
/*        
            {"L","T","T","pos","T"},
            {"L","T","T","pos","F"},
            {"L","T","T","neg","T"},
            {"L","T","T","neg","F"},
            {"L","T","F","pos","T"},
            {"L","T","F","pos","F"},
            {"L","T","F","neg","T"},
            {"L","T","F","neg","F"},
            {"L","F","T","pos","T"},
            {"L","F","T","pos","F"},
            {"L","F","T","neg","T"},
            {"L","F","T","neg","F"},
            {"L","F","F","pos","T"},
            {"L","F","F","pos","F"},
            {"L","F","F","neg","T"},
            {"L","F","F","neg","F"},
            {"H","T","T","pos","T"},
            {"H","T","T","pos","F"},
            {"H","T","T","neg","T"},
            {"H","T","T","neg","F"},
            {"H","T","F","pos","T"},
            {"H","T","F","pos","F"},
            {"H","T","F","neg","T"},
            {"H","T","F","neg","F"},
            {"H","F","T","pos","T"},
            {"H","F","T","pos","F"},
            {"H","F","T","neg","T"},
            {"H","F","T","neg","F"},
            {"H","F","F","pos","T"},
            {"H","F","F","pos","F"},
            {"H","F","F","neg","T"},
            {"H","F","F","neg","F"}        
            t[0][0][0][0][0] = 47;
            t[0][0][0][0][1] = 27;
            t[0][0][0][1][0] = 6;
            t[0][0][0][1][1] = 2;
            t[0][0][1][0][0] = 149;
            t[0][0][1][0][1] = 369;
            t[0][0][1][1][0] = 638;
            t[0][0][1][1][1] = 1477;
            t[0][1][0][0][0] = 9;
            t[0][1][0][0][1] = 4;
            t[0][1][0][1][0] = 0;
            t[0][1][0][1][1] = 1;
            t[0][1][1][0][0] = 381;
            t[0][1][1][0][1] = 842;
            t[0][1][1][1][0] = 1526;
            t[0][1][1][1][1] = 3506;
            t[1][0][0][0][0] = 8;
            t[1][0][0][0][1] = 4;
            t[1][0][0][1][0] = 0;
            t[1][0][0][1][1] = 0;
            t[1][0][1][0][0] = 20;
            t[1][0][1][0][1] = 38;
            t[1][0][1][1][0] = 70;
            t[1][0][1][1][1] = 166;
            t[1][1][0][0][0] = 13;
            t[1][1][0][0][1] = 5;
            t[1][1][0][1][0] = 1;
            t[1][1][0][1][1] = 0;
            t[1][1][1][0][0] = 36;
            t[1][1][1][0][1] = 101;
            t[1][1][1][1][0] = 171;
            t[1][1][1][1][1] = 383;
*/        
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));

        GL gl = drawable.getGL();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);

        // Setup the drawing area and shading mode
        gl.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        gl.glShadeModel(GL.GL_SMOOTH); // try setting this to GL_FLAT and see what happens.
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!
        
            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 1.0, 20.0);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        GL gl = drawable.getGL();

        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();

        // Move the "drawing cursor" around
        gl.glTranslatef(-1.5f, 0.0f, -6.0f);

        // Drawing Using Triangles
        gl.glBegin(GL.GL_TRIANGLES);
            gl.glColor3f(1.0f, 0.0f, 0.0f);    // Set the current drawing color to red
            gl.glVertex3f(0.0f, 1.0f, 0.0f);   // Top
            gl.glColor3f(0.0f, 1.0f, 0.0f);    // Set the current drawing color to green
            gl.glVertex3f(-1.0f, -1.0f, 0.0f); // Bottom Left
            gl.glColor3f(0.0f, 0.0f, 1.0f);    // Set the current drawing color to blue
            gl.glVertex3f(1.0f, -1.0f, 0.0f);  // Bottom Right
        // Finished Drawing The Triangle
        gl.glEnd();

        // Move the "drawing cursor" to another position
        gl.glTranslatef(3.0f, 0.0f, 0.0f);
        // Draw A Quad
        gl.glBegin(GL.GL_QUADS);
            gl.glColor3f(0.5f, 0.5f, 1.0f);    // Set the current drawing color to light blue
            gl.glVertex3f(-1.0f, 1.0f, 0.0f);  // Top Left
            gl.glVertex3f(1.0f, 1.0f, 0.0f);   // Top Right
            gl.glVertex3f(1.0f, -1.0f, 0.0f);  // Bottom Right
            gl.glVertex3f(-1.0f, -1.0f, 0.0f); // Bottom Left
        // Done Drawing The Quad
        gl.glEnd();

        // Flush all drawing operations to the graphics card
        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
}

