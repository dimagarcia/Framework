/*
 * Propiedad intelectual de la Universidad del Valle
 * Name:        BayesianMapper
 * Description: Bayesian network mapper
 * Author:      Diego Garcia
 * Date:        15th March 2016
 *
 * Modification Log:
 * ---------------------------
 * 2016-03-15   Diego Garcia    Creation.
 * 2016-03-28   Diego Garcia    Drop pa and frecuency atribbutes
 * 2016-03-29   Diego Garcia    Modify getQ:
 *                                  Drop Frequency.Table attribute
 */
package Sampler;

/**
 *
 * @author dgarcia
 */
public class BayesianMapper {
    
    public BayesianMapper(){
    }
    
    public int[] getQ(  Likelihood.BayesianModel b){
        int[] q = new int[b.v.length];
        
        for (int i=0; i<b.v.length; i++){
            q[i] = 1;
            if (!b.pa[i].isEmpty()){
                // Walking parents list
                List.ListNode<Integer> p = b.pa[i].queryNodeFromFront();
                while (p != null){
                    q[i] = q[i] * b.r[p.data];
                    
                    p = p.nextNode;
                }
            }
        }            
        
        return q;
    }  
    
    public int[][][] getN(  Likelihood.BayesianModel b,
                            Frequency.Table t){
        int[][][] n;
        
        // max j
        int max_j=0;
        for (int i=0; i<b.v.length; i++)
            if (max_j < b.r[i])
                max_j = b.r[i];
        // max k
        int max_k=0;
        for (int i=0; i<b.v.length; i++)
            if (max_k < b.q[i])
                max_k = b.q[i];
        
        n = new int[b.v.length][max_j][max_k];
        // To do: we must initialize n
        
        for (int i=0; i<b.v.length; i++){
            if (!b.pa[i].isEmpty()){
                
                for (int j=0; j<b.r[i]; j++){
                    n[i][j][0] = 0;
                    for (int l=0; l<t.m[i].length; j++){
                        if (t.m[i][l] == j){
                            n[i][j][0] +=  t.m[ t.m.length-1 ][l];
                        }
                    }
                    
                }
                
            }
            else{
                // Walking parents list
                List.ListNode<Integer> p = b.pa[i].queryNodeFromFront();
                while (p != null){
                    //q[i] = q[i] * b.r[p.data];
                    
                    p = p.nextNode;
                }      
                // 2016 04 05 11:00 To do: to construct set of parents values
                
                // Hypothesis (Ref. DGarcia)
//                for (int j=0; j<b.r[i]; j++){
//                    for (int k=0; k<b.q[i]; k++){
//                        n[i][j][k] = 0;
//                        for (int l=0; l<t.m[i].length; j++){
//                            if (t.m[i][l] == j
//                                t.m[0][l] == 0
//                                t.m[1][l] == 0){
//                                n[i][j][0] +=  t.m[ t.m.length-1 ][l];
//                            }
//                        }                        
//                    }
//                }
            }
            
            for (int j=0; j<b.r[i]; j++){
                for (int k=0; k<b.q[i]; k++){
                    // Count from t
                    if (i==0){
                        
                    }
//                    if (i==1)
//                    if (i==2)
//                    if (i==3)
//                    if (i==4)                        
                    //n[i][j][k] = t[i][j][k]
                }
            }
        }
        
        return null;
    }  
    
    public float[][][] getRho(Frequency.Table t){
        float[][][] rho;
        
        
        
        return null;
    }    
}
