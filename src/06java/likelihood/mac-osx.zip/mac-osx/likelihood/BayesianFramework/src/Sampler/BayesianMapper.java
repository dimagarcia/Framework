/*
 * Propiedad intelectual de la Universidad del Valle
 * Name:        BayesianMapper
 * Description: Bayesian network mapper
 * Author:      Diego Garcia
 * Date:        15th March 2016
 *
 * Modification Log:
 * ---------------------------
 * 2016-03-15   Diego Garcia    Creation.
 */
package Sampler;

/**
 *
 * @author dgarcia
 */
public class BayesianMapper {
    // patents
    public List.List pa[];
    // frecuency table
    public int[][] frecuency;
    
    
    public BayesianMapper(int d){
        pa = new List.List[d];
        for (int i=0; i<pa.length; i++)
            pa[i] = new List.List<Integer>();
    }
}
